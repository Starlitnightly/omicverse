﻿Pyomic.bulk.find\_DEG
=====================

.. currentmodule:: Pyomic.bulk

.. autofunction:: find_DEG