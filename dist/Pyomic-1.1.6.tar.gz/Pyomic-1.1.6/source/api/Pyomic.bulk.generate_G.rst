﻿Pyomic.bulk.generate\_G
=======================

.. currentmodule:: Pyomic.bulk

.. autofunction:: generate_G