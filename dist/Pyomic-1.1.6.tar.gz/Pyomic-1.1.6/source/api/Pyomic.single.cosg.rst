﻿Pyomic.single.cosg
==================

.. currentmodule:: Pyomic.single

.. autofunction:: cosg