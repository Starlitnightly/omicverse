﻿Pyomic.single.scnocd
====================

.. currentmodule:: Pyomic.single

.. autoclass:: scnocd

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~scnocd.GNN_configure
      ~scnocd.GNN_model
      ~scnocd.GNN_plot
      ~scnocd.GNN_preprocess
      ~scnocd.GNN_result
      ~scnocd.__init__
      ~scnocd.cal_nocd
      ~scnocd.calculate_nocd
      ~scnocd.get_nmi
      ~scnocd.matrix_normalize
      ~scnocd.matrix_transform
   
   

   
   
   