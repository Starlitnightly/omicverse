﻿Pyomic.bulk.enrichment\_GO
==========================

.. currentmodule:: Pyomic.bulk

.. autofunction:: enrichment_GO