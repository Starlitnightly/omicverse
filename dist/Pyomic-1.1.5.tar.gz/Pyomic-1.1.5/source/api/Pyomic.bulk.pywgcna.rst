﻿Pyomic.bulk.pywgcna
===================

.. currentmodule:: Pyomic.bulk

.. autoclass:: pywgcna

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~pywgcna.Analysis_cocharacter
      ~pywgcna.__init__
      ~pywgcna.calculate_corr_matrix
      ~pywgcna.calculate_correlation_direct
      ~pywgcna.calculate_correlation_indirect
      ~pywgcna.calculate_distance
      ~pywgcna.calculate_dynamicMods
      ~pywgcna.calculate_geneTree
      ~pywgcna.calculate_gene_module
      ~pywgcna.calculate_soft_threshold
   
   

   
   
   