﻿Pyomic.bulk.enrichment\_KEGG
============================

.. currentmodule:: Pyomic.bulk

.. autofunction:: enrichment_KEGG