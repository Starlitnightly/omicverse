﻿Pyomic.bulk.enrichment\_GSEA
============================

.. currentmodule:: Pyomic.bulk

.. autofunction:: enrichment_GSEA