﻿Pyomic.bulk.string\_interaction
===============================

.. currentmodule:: Pyomic.bulk

.. autofunction:: string_interaction