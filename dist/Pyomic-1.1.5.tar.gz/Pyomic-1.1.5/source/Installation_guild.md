# Installation guild

## Main package

The `Pyomic` package can be installed via pip using one of the following commands:

```
pip install -U Pyomic
```

**Note** To avoid potential dependency conflicts, installing within a pip environment is recommended.

